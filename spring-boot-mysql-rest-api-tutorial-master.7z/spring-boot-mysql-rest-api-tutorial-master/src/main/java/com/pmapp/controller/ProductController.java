package com.pmapp.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pmapp.model.Event;
import com.pmapp.model.Product;
import com.pmapp.repository.ProductRepository;


@RestController
@RequestMapping("/webapi")
public class ProductController {
    
    @Autowired
    ProductRepository productRepository;
    
    @PostMapping("/GetProducts")
    public List<Product> GetProducts(@Valid @RequestBody Event event) 
    {
    	List<Long> ids=new ArrayList<Long>();
    	for(Product product:event.getProducts())
    	{
    		ids.add(product.getId());
    	}
        return productRepository.findAllById(ids);
    }
    
    
    @PostMapping("/PutProducts")
    public List<Product> PutProducts(@Valid @RequestBody Event event) 
    {
    	List<Product> returnProducts=new ArrayList<Product>();
    	for(Product product:event.getProducts())
    	{
    		returnProducts.add(productRepository.save(product));
    	}
        return returnProducts;
    }
}