package com.pmapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "product")
@EntityListeners(AuditingEntityListener.class)

public class Product {
	
    @Id
    @Column(nullable = false, updatable = true)
	private long id;
    
    @Column(nullable = false, updatable = true)
	private String name;
	
    @Column(nullable = false, updatable = true)
    private int quantity;
    
    @Column(nullable = false, updatable = true)
	private double sale_amount;
	
	public Product() {
		
	}
	
	public Product(long id, String name, int quantity, double sale_amount) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.sale_amount = sale_amount;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getSale_amount() {
		return sale_amount;
	}

	public void setSale_amount(double sale_amount) {
		this.sale_amount = sale_amount;
	}
	
}
